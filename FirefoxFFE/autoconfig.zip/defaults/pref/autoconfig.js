pref("general.config.filename", "cck2.cfg");
pref("general.config.obscure_value", 0);
